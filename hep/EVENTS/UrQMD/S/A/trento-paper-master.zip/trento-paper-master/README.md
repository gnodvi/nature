# T<sub>R</sub>ENTo paper

http://arxiv.org/abs/1412.4708

This is the source repository for _An effective model for entropy deposition in high-energy pp, pA, and AA collisions_, which introduces the T<sub>R</sub>ENTo initial condition model.

See the `fig` subdirectory to generate figures.

Run `make` to compile the PDF using `latexmk`.

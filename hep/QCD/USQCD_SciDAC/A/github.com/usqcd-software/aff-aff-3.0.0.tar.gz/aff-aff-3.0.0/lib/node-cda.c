#include <stdint.h>
#include <stdarg.h>
#include "node-i.h"

struct AffNode_s *
aff_node_cda(struct AffTree_s *tree,
	     struct AffSTable_s *stable,
	     struct AffNode_s *n,
	     int create,
	     const char *p[])
{
    /* XXX */
    return 0;
}

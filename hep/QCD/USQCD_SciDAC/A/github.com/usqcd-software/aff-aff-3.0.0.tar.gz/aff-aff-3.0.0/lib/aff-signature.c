#include <stdint.h>
#include <stdio.h>
#include "md5.h"
#include "aff-i.h"
uint8_t aff_signature1[] = AFF_SIG1;
uint8_t aff_signature2[] = AFF_SIG2;
uint8_t aff_signature3[] = AFF_SIG3;

#ifndef MARK_7CBCDFBC_3E09_4F6D_BC09_694781B01ECA
#define MARK_7CBCDFBC_3E09_4F6D_BC09_694781B01ECA

int init_qdpcc_io(lua_State *L);
void fini_qdpcc_io(void);

#endif /* !defined(MARK_7CBCDFBC_3E09_4F6D_BC09_694781B01ECA) */

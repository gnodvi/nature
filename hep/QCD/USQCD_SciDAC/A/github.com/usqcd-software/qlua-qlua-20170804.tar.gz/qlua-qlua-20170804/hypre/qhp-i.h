#ifndef MARK_783E79AC_6CE0_4D0C_81B1_9E9896C6CFE6
#define MARK_783E79AC_6CE0_4D0C_81B1_9E9896C6CFE6

int qhp_init_mv(lua_State *L);
int qhp_fini_mv(lua_State *L);

int qhp_init_solvers(lua_State *L);
int qhp_fini_solvers(lua_State *L);

#endif /* defined(MARK_783E79AC_6CE0_4D0C_81B1_9E9896C6CFE6) */

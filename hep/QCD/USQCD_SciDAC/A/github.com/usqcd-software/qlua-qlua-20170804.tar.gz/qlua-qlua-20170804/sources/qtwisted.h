#ifndef MARK_D2372410_87D6_4C57_86AD_B1F1BEB62D78
#define MARK_D2372410_87D6_4C57_86AD_B1F1BEB62D78

int init_twisted(lua_State *L);
void fini_twisted(void);

#endif /* defined(MARK_D2372410_87D6_4C57_86AD_B1F1BEB62D78) */

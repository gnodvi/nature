#ifndef MILC_IO_H_F97B473E_C4D0_43D6_A8AA_85F0422B94CA
#define MILC_IO_H_F97B473E_C4D0_43D6_A8AA_85F0422B94CA

int init_milc_io(lua_State *L);
void fini_milc_io(void);

#endif /* !defined(MILC_IO_H_F97B473E_C4D0_43D6_A8AA_85F0422B94CA) */


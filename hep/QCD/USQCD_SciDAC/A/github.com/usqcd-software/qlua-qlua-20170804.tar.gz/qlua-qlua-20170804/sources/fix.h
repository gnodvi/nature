#ifndef MARK_43D088EC_3E63_4E7D_B93B_8A53C62717DC
#define MARK_43D088EC_3E63_4E7D_B93B_8A53C62717DC

int init_qlua_io(lua_State *L);
void fini_qlua_io(void);

#endif /* !defined(MARK_43D088EC_3E63_4E7D_B93B_8A53C62717DC) */

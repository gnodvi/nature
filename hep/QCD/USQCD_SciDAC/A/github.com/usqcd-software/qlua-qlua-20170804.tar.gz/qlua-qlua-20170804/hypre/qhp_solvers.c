#include "qlua.h"                           /* DEPS */
#include "qhp.h"                            /* DEPS */
#include "qhp-i.h"                          /* DEPS */

int
qhp_init_solvers(lua_State *L)
{
  /* XXX */
  return 0;
}

int
qhp_fini_solvers(lua_State *L)
{
  /* XXX */
  return 0;
}

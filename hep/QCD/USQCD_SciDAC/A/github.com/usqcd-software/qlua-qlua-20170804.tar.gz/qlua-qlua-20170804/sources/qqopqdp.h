#ifndef MARK_8FAC4F06_B83A_4C0E_9FF0_FFBFBD2597E1
#define MARK_8FAC4F06_B83A_4C0E_9FF0_FFBFBD2597E1

int init_qopqdp(lua_State *L);
void fini_qopqdp(void);

extern int qqq_inited;
/* QOPQDP library elements */
int qqq_wmg(lua_State *L);

#endif /* defined(MARK_8FAC4F06_B83A_4C0E_9FF0_FFBFBD2597E1) */

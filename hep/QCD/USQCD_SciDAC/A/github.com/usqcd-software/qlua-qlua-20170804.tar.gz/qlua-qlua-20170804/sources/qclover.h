#ifndef MARK_23B5D3A1_6865_4DC3_94A1_3A848AA1A2CB
#define MARK_23B5D3A1_6865_4DC3_94A1_3A848AA1A2CB

int init_clover(lua_State *L);
void fini_clover(void);

#endif /* !defined(MARK_23B5D3A1_6865_4DC3_94A1_3A848AA1A2CB) */

#ifndef MARK_BBCE8CD6_E32A_4C6A_B8AA_DE5963BC05BF
#define MARK_BBCE8CD6_E32A_4C6A_B8AA_DE5963BC05BF

int init_nersc_io(lua_State *L);
void fini_nersc_io(void);

#endif /* !defined(MARK_BBCE8CD6_E32A_4C6A_B8AA_DE5963BC05BF) */

#ifndef MARK_AA147196_743D_463D_A276_E4E4DBCFC11F
#define MARK_AA147196_743D_463D_A276_E4E4DBCFC11F

int init_qdpc_io(lua_State *L);
void fini_qdpc_io(void);

#endif /* !defined(MARK_AA147196_743D_463D_A276_E4E4DBCFC11F) */

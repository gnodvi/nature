#ifndef MARK_9FBF3350_05AD_4F83_A48B_2E2AA269B00E
#define MARK_9FBF3350_05AD_4F83_A48B_2E2AA269B00E

int init_ddpairs_io(lua_State *L);
void fini_ddpairs_io(void);

#endif /* !defined(MARK_9FBF3350_05AD_4F83_A48B_2E2AA269B00E) */

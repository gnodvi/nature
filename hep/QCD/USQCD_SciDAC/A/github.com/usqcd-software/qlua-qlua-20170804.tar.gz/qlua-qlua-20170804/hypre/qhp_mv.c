#include "qlua.h"                           /* DEPS */
#include "qhp.h"                            /* DEPS */
#include "qhp-i.h"                          /* DEPS */

int
qhp_init_mv(lua_State *L)
{
  /* XXX */
  return 0;
}

int
qhp_fini_mv(lua_State *L)
{
  /* XXX */
  return 0;
}

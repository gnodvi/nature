#define QOP_Precision 'F'
#define QOP_Colors 'N'
//#define QOP_Nc 
#define QDP_Precision 'F'
#define QDP_Colors 'N'
//#define QDP_Nc 
#define QLA_Precision 'F'
#define QLA_Colors 'N'
//#define QLA_Nc 

#include "mg/wilson_ops_p.c"

#define QDP_Precision 'D'
#define QOP_Precision 'D'

#include "hisq_reunit_utilities_p.c"

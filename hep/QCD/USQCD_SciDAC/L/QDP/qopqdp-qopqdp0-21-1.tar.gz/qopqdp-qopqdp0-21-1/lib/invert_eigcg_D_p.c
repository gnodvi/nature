#include <qop_internal.h>
#include <generic_D.h>

#include "invert_eigcg_p.c"

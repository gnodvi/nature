#define QOP_Precision 'D'
#define QOP_Colors 3
#define QOP_Nc 3
#define QDP_Precision 'D'
#define QDP_Colors 3
#define QDP_Nc 3
#define QLA_Precision 'D'
#define QLA_Colors 3
#define QLA_Nc 3

#include "wilson_invert_p.c"

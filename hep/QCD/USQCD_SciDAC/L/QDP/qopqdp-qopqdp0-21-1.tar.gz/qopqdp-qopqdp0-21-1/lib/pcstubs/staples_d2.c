#define QOP_Precision 'D'
#define QOP_Colors 2
#define QOP_Nc 2
#define QDP_Precision 'D'
#define QDP_Colors 2
#define QDP_Nc 2
#define QLA_Precision 'D'
#define QLA_Colors 2
#define QLA_Nc 2

#include "staples_p.c"

#include <qop_internal.h>
#include <generic_D.h>

#include "invert_utilities_p.c"

#define QOP_Precision 'F'
#define QOP_Colors 3
#define QOP_Nc 3
#define QDP_Precision 'F'
#define QDP_Colors 3
#define QDP_Nc 3
#define QLA_Precision 'F'
#define QLA_Colors 3
#define QLA_Nc 3

#include "asqtad_force_asvec_p.c"

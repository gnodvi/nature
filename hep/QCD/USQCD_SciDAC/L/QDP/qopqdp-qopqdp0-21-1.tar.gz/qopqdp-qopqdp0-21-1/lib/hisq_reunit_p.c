#include "hisq_reunit2_p.c"

#if QOP_Colors == 3
#include "hisq_reunit1_p.c"
#endif

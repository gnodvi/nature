#include <qop_internal.h>
#include <generic_vD.h>

#include "invert_utilities_p.c"


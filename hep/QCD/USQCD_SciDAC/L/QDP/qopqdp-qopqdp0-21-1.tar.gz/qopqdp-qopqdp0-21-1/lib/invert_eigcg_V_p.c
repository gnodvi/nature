#include <qop_internal.h>
#include <generic_V.h>

#include "invert_eigcg_p.c"

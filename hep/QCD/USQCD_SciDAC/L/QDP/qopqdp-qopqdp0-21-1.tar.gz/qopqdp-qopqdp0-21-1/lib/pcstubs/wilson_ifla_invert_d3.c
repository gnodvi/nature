#define QDP_Precision 'D'
#define QOP_Precision 'D'

#include "wilson_ifla_invert_p.c"

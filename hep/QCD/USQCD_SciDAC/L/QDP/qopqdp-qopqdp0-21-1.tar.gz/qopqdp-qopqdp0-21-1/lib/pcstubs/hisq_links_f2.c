#define QOP_Precision 'F'
#define QOP_Colors 2
#define QOP_Nc 2
#define QDP_Precision 'F'
#define QDP_Colors 2
#define QDP_Nc 2
#define QLA_Precision 'F'
#define QLA_Colors 2
#define QLA_Nc 2

#include "hisq_links_p.c"

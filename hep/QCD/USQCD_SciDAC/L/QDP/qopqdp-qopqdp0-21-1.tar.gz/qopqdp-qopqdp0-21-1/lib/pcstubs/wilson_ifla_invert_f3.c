#define QDP_Precision 'F'
#define QOP_Precision 'F'

#include "wilson_ifla_invert_p.c"

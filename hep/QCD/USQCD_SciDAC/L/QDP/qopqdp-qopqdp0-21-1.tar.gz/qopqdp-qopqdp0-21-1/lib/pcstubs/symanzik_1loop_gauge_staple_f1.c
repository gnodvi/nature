#define QOP_Precision 'F'
#define QOP_Colors 1
#define QOP_Nc 1
#define QDP_Precision 'F'
#define QDP_Colors 1
#define QDP_Nc 1
#define QLA_Precision 'F'
#define QLA_Colors 1
#define QLA_Nc 1

#include "symanzik_1loop_gauge_staple_p.c"

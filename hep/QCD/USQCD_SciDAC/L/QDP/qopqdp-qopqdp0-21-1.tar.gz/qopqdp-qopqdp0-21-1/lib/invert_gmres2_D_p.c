#include <qop_internal.h>
#include <generic_D.h>

#include "invert_gmres2_p.c"

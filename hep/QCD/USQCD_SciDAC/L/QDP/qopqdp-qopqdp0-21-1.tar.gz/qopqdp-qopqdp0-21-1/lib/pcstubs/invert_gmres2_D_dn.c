#define QOP_Precision 'D'
#define QOP_Colors 'N'
//#define QOP_Nc 
#define QDP_Precision 'D'
#define QDP_Colors 'N'
//#define QDP_Nc 
#define QLA_Precision 'D'
#define QLA_Colors 'N'
//#define QLA_Nc 

#include "invert_gmres2_D_p.c"

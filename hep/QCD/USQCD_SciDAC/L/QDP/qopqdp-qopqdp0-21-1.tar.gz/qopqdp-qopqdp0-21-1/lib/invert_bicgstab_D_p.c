#include <qop_internal.h>
#include <generic_D.h>

#include "invert_bicgstab_p.c"

#define QOP_Precision 'D'
#include <qop_internal.h>


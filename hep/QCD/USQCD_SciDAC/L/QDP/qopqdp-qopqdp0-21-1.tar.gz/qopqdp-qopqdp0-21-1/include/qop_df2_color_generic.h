// DO NOT EDIT
// generated from qop_pc.h
#ifndef _QOP_2__C_GENERIC_H
#define _QOP_2__C_GENERIC_H

#define QOP_wilsonMgFree QOP_2_wilsonMgFree
#define QOP_wilsonMgNew QOP_2_wilsonMgNew
#define QOP_WilsonMg QOP_2_WilsonMg
#define QOP_wilsonMgSetArray QOP_2_wilsonMgSetArray
#define QOP_wilsonMgSet QOP_2_wilsonMgSet
#define QOP_wilsonMgSetup QOP_2_wilsonMgSetup
#define QOP_WilsonMgStruct QOP_2_WilsonMgStruct

#endif // _QOP_2__C_GENERIC_H
// DO NOT EDIT
// generated from qop_poc.h
#ifndef _QOP_FD2_FD_POC_GENERIC_H
#define _QOP_FD2_FD_POC_GENERIC_H

#define QOP_FD_asqtad_create_L_from_L QOP_FD2_asqtad_create_L_from_L
#define QOP_FD_create_G_from_G QOP_FD2_create_G_from_G
#define QOP_FD_create_G_from_qdp QOP_FD2_create_G_from_qdp
#define QOP_FD_wilson_create_L_from_L QOP_FD2_wilson_create_L_from_L

#endif // _QOP_FD2_FD_POC_GENERIC_H
// DO NOT EDIT
// generated from qop_poc.h
#ifndef _QOP_DF2_DF_POC_GENERIC_H
#define _QOP_DF2_DF_POC_GENERIC_H

#define QOP_DF_asqtad_create_L_from_L QOP_DF2_asqtad_create_L_from_L
#define QOP_DF_create_G_from_G QOP_DF2_create_G_from_G
#define QOP_DF_create_G_from_qdp QOP_DF2_create_G_from_qdp
#define QOP_DF_wilson_create_L_from_L QOP_DF2_wilson_create_L_from_L

#endif // _QOP_DF2_DF_POC_GENERIC_H

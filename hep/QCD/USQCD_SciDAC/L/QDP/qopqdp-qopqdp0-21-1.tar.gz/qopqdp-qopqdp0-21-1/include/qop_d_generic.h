// DO NOT EDIT
// generated from qop_p.h
#ifndef _QOP_D__P_GENERIC_H
#define _QOP_D__P_GENERIC_H

#define QOP_Real QOP_D_Real

#endif // _QOP_D__P_GENERIC_H

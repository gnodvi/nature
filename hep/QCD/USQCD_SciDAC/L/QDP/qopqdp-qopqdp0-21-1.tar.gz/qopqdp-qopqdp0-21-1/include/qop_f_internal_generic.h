// DO NOT EDIT
// generated from qop_p_internal.h
#ifndef _QOP_F__IP_GENERIC_H
#define _QOP_F__IP_GENERIC_H

#define fromQDP fromQDPF
#define get_qll_layout get_qll_layoutF
#define QOP_Gcr QOP_F_Gcr
#define QOP_GcrSolveArgs QOP_F_GcrSolveArgs
#define QOP_MgVcycleArgs QOP_F_MgVcycleArgs
#define QOP_mgVcycle QOP_F_mgVcycle
#define setup_qll setup_qllF
#define setup_quda setup_qudaF
#define toQDP toQDPF

#endif // _QOP_F__IP_GENERIC_H

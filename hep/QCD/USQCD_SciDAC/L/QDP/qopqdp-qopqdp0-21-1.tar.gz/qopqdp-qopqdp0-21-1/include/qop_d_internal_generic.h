// DO NOT EDIT
// generated from qop_p_internal.h
#ifndef _QOP_D__IP_GENERIC_H
#define _QOP_D__IP_GENERIC_H

#define fromQDP fromQDPD
#define get_qll_layout get_qll_layoutD
#define QOP_Gcr QOP_D_Gcr
#define QOP_GcrSolveArgs QOP_D_GcrSolveArgs
#define QOP_MgVcycleArgs QOP_D_MgVcycleArgs
#define QOP_mgVcycle QOP_D_mgVcycle
#define setup_qll setup_qllD
#define setup_quda setup_qudaD
#define toQDP toQDPD

#endif // _QOP_D__IP_GENERIC_H

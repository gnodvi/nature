// DO NOT EDIT
// generated from qop_pc.h
#ifndef _QOP_3__C_GENERIC_H
#define _QOP_3__C_GENERIC_H

#define QOP_wilsonMgFree QOP_3_wilsonMgFree
#define QOP_wilsonMgNew QOP_3_wilsonMgNew
#define QOP_WilsonMg QOP_3_WilsonMg
#define QOP_wilsonMgSetArray QOP_3_wilsonMgSetArray
#define QOP_wilsonMgSet QOP_3_wilsonMgSet
#define QOP_wilsonMgSetup QOP_3_wilsonMgSetup
#define QOP_WilsonMgStruct QOP_3_WilsonMgStruct

#endif // _QOP_3__C_GENERIC_H
// DO NOT EDIT
// generated from qop_poc.h
#ifndef _QOP_FD3_FD_POC_GENERIC_H
#define _QOP_FD3_FD_POC_GENERIC_H

#define QOP_FD_asqtad_create_L_from_L QOP_FD3_asqtad_create_L_from_L
#define QOP_FD_create_G_from_G QOP_FD3_create_G_from_G
#define QOP_FD_create_G_from_qdp QOP_FD3_create_G_from_qdp
#define QOP_FD_wilson_create_L_from_L QOP_FD3_wilson_create_L_from_L

#endif // _QOP_FD3_FD_POC_GENERIC_H
// DO NOT EDIT
// generated from qop_poc.h
#ifndef _QOP_DF3_DF_POC_GENERIC_H
#define _QOP_DF3_DF_POC_GENERIC_H

#define QOP_DF_asqtad_create_L_from_L QOP_DF3_asqtad_create_L_from_L
#define QOP_DF_create_G_from_G QOP_DF3_create_G_from_G
#define QOP_DF_create_G_from_qdp QOP_DF3_create_G_from_qdp
#define QOP_DF_wilson_create_L_from_L QOP_DF3_wilson_create_L_from_L

#endif // _QOP_DF3_DF_POC_GENERIC_H

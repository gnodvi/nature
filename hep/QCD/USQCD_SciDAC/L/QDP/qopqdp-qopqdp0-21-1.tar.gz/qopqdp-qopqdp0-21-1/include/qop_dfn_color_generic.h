// DO NOT EDIT
// generated from qop_pc.h
#ifndef _QOP_N__C_GENERIC_H
#define _QOP_N__C_GENERIC_H

#define QOP_wilsonMgFree QOP_N_wilsonMgFree
#define QOP_wilsonMgNew QOP_N_wilsonMgNew
#define QOP_WilsonMg QOP_N_WilsonMg
#define QOP_wilsonMgSetArray QOP_N_wilsonMgSetArray
#define QOP_wilsonMgSet QOP_N_wilsonMgSet
#define QOP_wilsonMgSetup QOP_N_wilsonMgSetup
#define QOP_WilsonMgStruct QOP_N_WilsonMgStruct

#endif // _QOP_N__C_GENERIC_H
// DO NOT EDIT
// generated from qop_poc.h
#ifndef _QOP_FDN_FD_POC_GENERIC_H
#define _QOP_FDN_FD_POC_GENERIC_H

#define QOP_FD_asqtad_create_L_from_L QOP_FDN_asqtad_create_L_from_L
#define QOP_FD_create_G_from_G QOP_FDN_create_G_from_G
#define QOP_FD_create_G_from_qdp QOP_FDN_create_G_from_qdp
#define QOP_FD_wilson_create_L_from_L QOP_FDN_wilson_create_L_from_L

#endif // _QOP_FDN_FD_POC_GENERIC_H
// DO NOT EDIT
// generated from qop_poc.h
#ifndef _QOP_DFN_DF_POC_GENERIC_H
#define _QOP_DFN_DF_POC_GENERIC_H

#define QOP_DF_asqtad_create_L_from_L QOP_DFN_asqtad_create_L_from_L
#define QOP_DF_create_G_from_G QOP_DFN_create_G_from_G
#define QOP_DF_create_G_from_qdp QOP_DFN_create_G_from_qdp
#define QOP_DF_wilson_create_L_from_L QOP_DFN_wilson_create_L_from_L

#endif // _QOP_DFN_DF_POC_GENERIC_H

// DO NOT EDIT
// generated from qop_pc.h
#ifndef _QOP_1__C_GENERIC_H
#define _QOP_1__C_GENERIC_H

#define QOP_wilsonMgFree QOP_1_wilsonMgFree
#define QOP_wilsonMgNew QOP_1_wilsonMgNew
#define QOP_WilsonMg QOP_1_WilsonMg
#define QOP_wilsonMgSetArray QOP_1_wilsonMgSetArray
#define QOP_wilsonMgSet QOP_1_wilsonMgSet
#define QOP_wilsonMgSetup QOP_1_wilsonMgSetup
#define QOP_WilsonMgStruct QOP_1_WilsonMgStruct

#endif // _QOP_1__C_GENERIC_H
// DO NOT EDIT
// generated from qop_poc.h
#ifndef _QOP_FD1_FD_POC_GENERIC_H
#define _QOP_FD1_FD_POC_GENERIC_H

#define QOP_FD_asqtad_create_L_from_L QOP_FD1_asqtad_create_L_from_L
#define QOP_FD_create_G_from_G QOP_FD1_create_G_from_G
#define QOP_FD_create_G_from_qdp QOP_FD1_create_G_from_qdp
#define QOP_FD_wilson_create_L_from_L QOP_FD1_wilson_create_L_from_L

#endif // _QOP_FD1_FD_POC_GENERIC_H
// DO NOT EDIT
// generated from qop_poc.h
#ifndef _QOP_DF1_DF_POC_GENERIC_H
#define _QOP_DF1_DF_POC_GENERIC_H

#define QOP_DF_asqtad_create_L_from_L QOP_DF1_asqtad_create_L_from_L
#define QOP_DF_create_G_from_G QOP_DF1_create_G_from_G
#define QOP_DF_create_G_from_qdp QOP_DF1_create_G_from_qdp
#define QOP_DF_wilson_create_L_from_L QOP_DF1_wilson_create_L_from_L

#endif // _QOP_DF1_DF_POC_GENERIC_H

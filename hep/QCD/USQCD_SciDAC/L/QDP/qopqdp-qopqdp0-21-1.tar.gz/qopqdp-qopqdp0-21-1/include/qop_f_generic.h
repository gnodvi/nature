// DO NOT EDIT
// generated from qop_p.h
#ifndef _QOP_F__P_GENERIC_H
#define _QOP_F__P_GENERIC_H

#define QOP_Real QOP_F_Real

#endif // _QOP_F__P_GENERIC_H

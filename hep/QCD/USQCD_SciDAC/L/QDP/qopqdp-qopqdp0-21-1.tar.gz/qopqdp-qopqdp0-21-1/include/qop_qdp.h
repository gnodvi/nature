#ifndef _QOP_QDP_H
#define _QOP_QDP_H

#include <qop.h>
#include <qdp.h>

#endif /* _QOP_QDP_H */

#ifndef _QDP_SUBSET_INTERNAL_H
#define _QDP_SUBSET_INTERNAL_H

extern void QDP_make_subsets(void);

#endif

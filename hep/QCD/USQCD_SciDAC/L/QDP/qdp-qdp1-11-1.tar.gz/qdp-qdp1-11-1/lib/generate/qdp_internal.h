#ifndef _QDP_$LIB_INTERNAL_H
#define _QDP_$LIB_INTERNAL_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "qdp_internal.h"
#include "qdp_$lib.h"
#include "qla.h"
#include "qla_$lib.h"
!QLAELIBS
#include "qla_$elib.h"
!END

#endif

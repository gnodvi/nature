#!/bin/tcsh

../configure --prefix=/usr/local/share/qmp/single --with-qmp-comms-type=SINGLE 

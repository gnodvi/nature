#ifndef TEST_VAYPX
#define TEST_VAYPX


#ifndef UNITTEST_H
#include "unittest.h"
#endif


class testVaypx4_1 : public TestFixture { public: void run(void); };
class testVaypx4_2 : public TestFixture { public: void run(void); };
class testVaypx4_3 : public TestFixture { public: void run(void); };

#endif

const int nrow_in[] = {8,8,8,8};

using blueqat
using Test

@testset "blueqat.jl" begin
    # Write your tests here.
end

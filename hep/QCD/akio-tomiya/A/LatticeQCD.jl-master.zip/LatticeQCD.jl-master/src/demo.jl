include("./LatticeQCD.jl")
using Plots
using .LatticeQCD
using Random
using Dates
#using JLD
#using GFlops


@time demo()
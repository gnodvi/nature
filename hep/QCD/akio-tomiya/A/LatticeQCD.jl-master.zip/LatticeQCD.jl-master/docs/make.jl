using LatticeQCD
using Documenter

makedocs(sitename="LatticeQCD.jl")

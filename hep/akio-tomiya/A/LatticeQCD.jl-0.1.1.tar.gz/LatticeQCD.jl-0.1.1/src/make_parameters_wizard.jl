include("LatticeQCD.jl")
using .LatticeQCD
run_wizard()
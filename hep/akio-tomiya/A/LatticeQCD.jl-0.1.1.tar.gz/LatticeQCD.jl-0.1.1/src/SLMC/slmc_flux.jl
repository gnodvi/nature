module SLMC_Flux
    using Flux
end